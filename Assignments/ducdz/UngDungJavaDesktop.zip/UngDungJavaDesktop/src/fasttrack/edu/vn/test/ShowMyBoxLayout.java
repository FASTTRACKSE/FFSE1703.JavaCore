package fasttrack.edu.vn.test;

import fasttrack.edu.vn.ui.*;

public class ShowMyBoxLayout {

	public static void main(String[] args) {
		MyBoxLayoutUI myUI = new MyBoxLayoutUI("Box Layout cua Thanh");
		myUI.showWindow();

	}

}
