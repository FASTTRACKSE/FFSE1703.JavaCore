package fasttrack.edu.vn.test;

import fasttrack.edu.vn.ui.*;

public class ShowMyFlowLayout {

	public static void main(String[] args) {
		MyFlowLayoutUI myUI = new MyFlowLayoutUI("Flow layout");
		myUI.showWindow();
		
	}

}
