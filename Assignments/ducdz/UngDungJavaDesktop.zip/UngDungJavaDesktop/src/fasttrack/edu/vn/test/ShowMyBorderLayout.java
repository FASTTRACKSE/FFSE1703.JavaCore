package fasttrack.edu.vn.test;

import fasttrack.edu.vn.ui.MyBorderLayoutUI;

public class ShowMyBorderLayout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyBorderLayoutUI myUI = new MyBorderLayoutUI("Border Layout");
		myUI.showWindow();

	}

}
